

# A simple linear chain workflow

## Workflow development principles

- 

## Example: Somatic variation workflow

`tg-wdl-LILAC-workflow` is a consensus variant calling workflow for human hybrid capture-based paired-sample panel based DNA sequencing.

We want to build it up from scratch!
